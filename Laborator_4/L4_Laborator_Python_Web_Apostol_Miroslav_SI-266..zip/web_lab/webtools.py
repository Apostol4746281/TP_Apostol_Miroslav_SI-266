# Laborator: functii, metode si importuri pe web
# Student: Apostol Miroslav, grupa SI-266

import time
import json
import csv
import socket
import ssl
from datetime import datetime
from urllib.parse import urlparse, urljoin
import requests

BASE_URL = "https://cybercor.org"
TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-ApostolMiroslav"}  # Exercitiul 47

def fetch(url: str, timeout: int = TIMEOUT):
    """Descarca o pagina web folosind antetele implicite si un timeout."""
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)

def get_status(url: str) -> int:
    """Returneaza codul de stare HTTP pentru adresa url."""
    r = fetch(url)
    return r.status_code

def get_title(html: str) -> str:
    """Extrage si returneaza titlul paginii dintr-un sir HTML."""
    start = html.find("<title>") + len("<title>")
    final = html.find("</title>")
    if start > len("<title>") - 1 and final != -1:
        return html[start:final].strip()
    return "Fara titlu"

def security_headers(url: str) -> dict:
    """Verifica prezenta celor 5 antete importante de securitate."""
    antete_cerute = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    r = fetch(url)
    verificare = {}
    for antet in antete_cerute:
        verificare[antet] = antet in r.headers
    return verificare

def score_headers(results: dict) -> str:
    """Calculeaza un scor de tip 'X/5' bazat pe antetele de securitate gasite."""
    total = len(results)
    gasite = sum(1 for val in results.values() if val)
    return f"{gasite}/{total}"

def check_paths(base: str, paths: list) -> dict:
    """Verifica o lista de cai si returneaza un dictionar cu statusurile lor."""
    rezultate = {}
    for p in paths:
        url_complet = base + p
        try:
            r = fetch(url_complet)
            rezultate[p] = r.status_code
        except requests.RequestException:
            rezultate[p] = None
        time.sleep(1)
    return rezultate

def resolve(hostname: str) -> str:
    """Returneaza adresa IP a unui hostname."""
    return socket.gethostbyname(hostname)

def cert_days_left(hostname: str) -> int:
    """Calculeaza cate zile mai sunt pana la expirarea certificatului SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            data_secunde = ssl.cert_time_to_seconds(cert["notAfter"])
            return int((data_secunde - time.time()) // 86400)

def fetch_robots(base: str) -> str:
    """Descarca continutul fisierului robots.txt."""
    try:
        r = fetch(base + "/robots.txt")
        if r.status_code == 200:
            return r.text
    except requests.RequestException:
        pass
    return None

def disallowed_paths(robots_text: str) -> list:
    """Extrage caile interzise din textul fisierului robots.txt."""
    if robots_text is None:
        return []
    rezultat = []
    for linie in robots_text.splitlines():
        if "Disallow:" in linie:
            val = linie.split("Disallow:")[1].strip()
            if val:
                rezultat.append(val)
    return rezultat

def site_report(url: str):
    """Genereaza raportul complet al site-ului (Exercitiul 50), il afiseaza si il salveaza in report.json."""
    # 1. Cod de stare si URL final
    r = fetch(url)
    status = r.status_code
    final_url = r.url

    # 2. Titlu
    titlu = get_title(r.text)

    # 3. Adresa IP
    parsed_u = urlparse(url)
    try:
        ip = resolve(parsed_u.netloc)
    except Exception:
        ip = "Indisponibil"

    # 4. Redirectionari pornind de la http://
    http_url = url.replace("https://", "http://")
    redirectionari_text = "Nicio redirectionare"
    try:
        r_redir = requests.get(http_url, headers=DEFAULT_HEADERS, timeout=TIMEOUT)
        if r_redir.history:
            istoric_str = " -> ".join([str(h.status_code) for h in r_redir.history])
            redirectionari_text = f"{istoric_str} -> {r_redir.url}"
    except Exception:
        pass

    # 5. Scor securitate
    sec_dict = security_headers(url)
    scor_sec = score_headers(sec_dict)

    # 6. Zile certificate
    try:
        zile_cert = cert_days_left(parsed_u.netloc)
        cert_text = f"{zile_cert} de zile ramase"
    except Exception:
        cert_text = "Necunoscut"

    # 7. Legaturi interne si externe
    import re
    toate_href = re.findall(r'href="([^"]+)"', r.text)
    interne = 0
    externe = 0
    for h in toate_href:
        compl = urljoin(url, h)
        if parsed_u.netloc in urlparse(compl).netloc:
            interne += 1
        else:
            externe += 1

    # 8. Cai interzise din robots.txt
    rob_txt = fetch_robots(url)
    cai_interzise = disallowed_paths(rob_txt)
    cai_str = ", ".join(cai_interzise) if cai_interzise else "Niciuna"

    # Afisare raport in consola
    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare:      {status}")
    print(f"Titlu:             {titlu}")
    print(f"Adresa IP:         {ip}")
    print(f"Redirectionari:    {redirectionari_text}")
    print(f"Scor securitate:   {scor_sec}")
    print(f"Certificat:        {cert_text}")
    print(f"Legaturi:          {interne} interne, {externe} externe")
    print(f"Cai interzise:     {cai_str}")
    print("Salvat in report.json")

    # Salvare in report.json
    date_raport = {
        "url": url,
        "status_code": status,
        "title": titlu,
        "ip_address": ip,
        "redirects": redirectionari_text,
        "security_score": scor_sec,
        "certificate_days_left": cert_text,
        "internal_links": interne,
        "external_links": externe,
        "disallowed_paths": cai_interzise
    }
    with open("report.json", "w", encoding="utf-8") as f:
        json.dump(date_raport, f, indent=2)

# Exercitiul 46. Blocul main
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
    # Explicare de ce autotestul ruleaza doar aici:
    # Cand rulez 'python webtools.py', variabila __name__ devine '__main__', deci autotestul 
    # se executa. Cand import webtools din main.py, variabila __name__ devine 'webtools', 
    # asa ca acest bloc nu se mai executa automat in main.py[cite: 1].