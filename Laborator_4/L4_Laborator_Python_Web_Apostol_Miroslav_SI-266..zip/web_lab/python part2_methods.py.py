# Laborator: functii, metode si importuri pe web
# Student: Apostol Miroslav, grupa SI-266

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Exercitiul 9. Elementele de baza ale raspunsului
print("--- Exercitiul 9 ---")
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("status_code:", response.status_code)       # ATRIBUT
print("ok:", response.ok)                         # ATRIBUT
print("url:", response.url)                         # ATRIBUT
print("encoding:", response.encoding)             # ATRIBUT

time.sleep(1)

# Exercitiul 10. Tratarea erorilor cu o metoda
print("\n--- Exercitiul 10 ---")
try:
    response.raise_for_status() # Metoda care verifica daca cererea s-a incheiat cu bine
    print("Pagina principala s-a incarcat cu succes!")
    
    url_gresit = BASE_URL + "/this-page-does-not-exist"
    resp_gresit = requests.get(url_gresit, timeout=TIMEOUT)
    resp_gresit.raise_for_status()
except requests.HTTPError as e:
    print("Am prins o eroare HTTP in mod prietenos:", e)

time.sleep(1)

# Exercitiul 11. Toate antetele
print("\n--- Exercitiul 11 ---")
for nume, valoare in response.headers.items():
    print(f"{nume}: {valoare}")

time.sleep(1)

# Exercitiul 12. Metode de dictionar
print("\n--- Exercitiul 12 ---")
server = response.headers.get("Server", "lipseste")
content_type = response.headers.get("Content-Type", "lipseste")
print("Antet Server:", server)
print("Antet Content-Type:", content_type)

content_type_mic = response.headers.get("content-type", "lipseste")
print("Antet content-type (cu litere mici):", content_type_mic)
# Observatie: dictionarul de antete din requests este case-insensitive, adica 
# gaseste cheia indiferent daca o scriu cu litere mici sau mari.

time.sleep(1)

# Exercitiul 13. Inlantuirea metodelor de sir
print("\n--- Exercitiul 13 ---")
numar_aparitii = response.text.lower().count("cyber")
print("Cuvantul 'cyber' apare de atatea ori:", numar_aparitii)
# Pot inlanti .lower() si .count() pentru ca .lower() returneaza un sir de caractere 
# nou (string), iar pe acel sir nou pot apela direct o alta metoda, precum .count().

time.sleep(1)

# Exercitiul 14. Gasirea titlului
print("\n--- Exercitiul 14 ---")
html_text = response.text
start = html_text.find("<title>") + len("<title>")
final = html_text.find("</title>")
titlu = html_text[start:final].strip()
print("Titlul extras:", titlu)

time.sleep(1)

# Exercitiul 15. Numararea liniilor
print("\n--- Exercitiul 15 ---")
linii = html_text.splitlines()
cea_mai_lunga = max(linii, key=len)
print("Numar total de linii:", len(linii))
print("Lungimea celei mai lungi linii:", len(cea_mai_lunga))

time.sleep(1)

# Exercitiul 16. Verificarea HTTPS
print("\n--- Exercitiul 16 ---")
if response.url.startswith("https://"):
    print("Conexiune securizata")
else:
    print("Conexiune nesecurizata")

time.sleep(1)

# Exercitiul 17. Urmarirea redirectionarilor
print("\n--- Exercitiul 17 ---")
resp_redir = requests.get("http://cybercor.org", timeout=TIMEOUT)
print("Istoricul redirectionarilor:")
for r in resp_redir.history:
    print("Cod stare:", r.status_code, "-> URL:", r.url)
print("URL-ul final:", resp_redir.url)

time.sleep(1)

# Exercitiul 18. HEAD versus GET
print("\n--- Exercitiul 18 ---")
resp_head = requests.head(BASE_URL, timeout=TIMEOUT)
resp_get = requests.get(BASE_URL, timeout=TIMEOUT)
print("Lungime continut HEAD:", len(resp_head.content))
print("Lungime continut GET:", len(resp_get.content))
# Diferenta: o cerere HEAD descarca doar antetele de la server (corpul are lungimea 0), 
# pe cand o cerere GET descarca intregul continut HTML al paginii.

time.sleep(1)

# Exercitiul 19. Cookie-uri
print("\n--- Exercitiul 19 ---")
if len(response.cookies) == 0:
    print("Niciun cookie setat")
else:
    for cookie in response.cookies:
        print(f"Cookie: {cookie.name}, Secure: {cookie.secure}")

time.sleep(1)

# Exercitiul 20. Sesiuni
print("\n--- Exercitiul 20 ---")
sesiune = requests.Session()
sesiune.headers.update({"User-Agent": "WebLab-ApostolMiroslav"})
resp_sesiune = sesiune.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print("Rezultat JSON de la Echo Headers:")
print(resp_sesiune.json())
# De ce response.text nu are paranteze, iar response.json() are? 
# Deoarece response.text este un atribut (o proprietate care stocheaza textul), 
# in timp ce response.json() este o metoda (o actiune care parseaza textul primit si 
# il transforma intr-un dictionar Python).