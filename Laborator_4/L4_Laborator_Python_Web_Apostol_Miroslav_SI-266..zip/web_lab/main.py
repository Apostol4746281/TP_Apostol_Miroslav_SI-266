# Laborator: functii, metode si importuri pe web
# Student: Apostol Miroslav, grupa SI-266

import sys
import csv
from datetime import datetime
import webtools

# Exercitiul 45. Importarea anumitor nume
from webtools import get_title, security_headers
# Ce s-ar intampla daca in main.py as avea si o functie proprie numita get_title?
# Raspuns (comentariu): Daca as defini o functie locala def get_title(): in acest fisier, 
# Python ar folosi functia mea locala si ar suprascrie/ignora functia importata din 
# modulul webtools, deoarece namespace-ul local are prioritate absoluta[cite: 1].

def main():
    # Exercitiul 48. Argumente din linia de comanda (folosind sys.argv)
    url_tinta = webtools.BASE_URL
    if len(sys.argv) > 1:
        url_tinta = sys.argv[1]

    print("--- Exercitiul 44 ---")
    # Apelul cerut la exercitiul 44 folosind modulul importat:
    titlu_ex44 = webtools.get_title(webtools.fetch(url_tinta).text)
    print("Titlul extras (prin webtools.get_title):", titlu_ex44)

    print("\n--- Exercitiul 45 ---")
    # Apelul functiei importate direct prin 'from webtools import get_title'
    r_ex45 = webtools.fetch(url_tinta)
    titlu_ex45 = get_title(r_ex45.text)
    print("Titlul extras (prin functia importata direct):", titlu_ex45)

    print("\n--- Exercitiul 47 ---")
    # Afisarea constantei de modul importate din webtools.py
    print("Constanta DEFAULT_HEADERS importata:", webtools.DEFAULT_HEADERS)
    print(" Aceasta constanta a fost folosita automat in functia fetch() din modul.")

    print("\n--- Exercitiul 46 ---")
    print("Blocul main din webtools.py a fost oprit la import (explicat in comentariile din webtools.py).")

    print("\n--- Exercitiul 49 (Raport CSV) ---")
    cai_de_verificat = ["/", "/robots.txt", "/sitemap.xml"]
    rezultate_verificare = webtools.check_paths(url_tinta, cai_de_verificat)
    ora_curenta = datetime.now().isoformat()
    
    with open("report.csv", "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["path", "status", "checked_at"])
        for calea, cod in rezultate_verificare.items():
            writer.writerow([calea, cod, ora_curenta])
    print("Fisierul report.csv a fost generat si salvat cu succes!")

    print("\n--- Exercitiul 50 (Proiect final) ---")
    webtools.site_report(url_tinta)

if __name__ == "__main__":
    main()