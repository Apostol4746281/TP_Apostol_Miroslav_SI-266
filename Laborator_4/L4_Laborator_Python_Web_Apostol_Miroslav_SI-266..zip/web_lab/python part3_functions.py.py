# Laborator: functii, metode si importuri pe web
# Student: Apostol Miroslav, grupa SI-266

import time
import requests

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

# Exercitiul 21. Prima functie
def fetch(url: str):
    """Trimite o cerere GET catre url si returneaza obiectul raspuns."""
    return requests.get(url, timeout=TIMEOUT)

print("--- Exercitiul 21 ---")
r_ex21 = fetch(BASE_URL)
print("Cod de stare prin functia fetch:", r_ex21.status_code)

time.sleep(1)

# Exercitiul 22. Returnarea unei singure valori
def get_status(url: str) -> int:
    """Returneaza codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

print("\n--- Exercitiul 22 ---")
for c in ["/", "/robots.txt", "/sitemap.xml"]:
    full_u = BASE_URL + c
    print(f"Calea {c} are statusul:", get_status(full_u))
    time.sleep(1)

# Exercitiul 23. Parametri impliciti
def fetch_cu_timeout(url: str, timeout: int = 10):
    """Descarca o pagina avand un timeout configurabil."""
    return requests.get(url, timeout=timeout)

print("\n--- Exercitiul 23 ---")
print("Cu timeout implicit:", fetch_cu_timeout(BASE_URL).status_code)
time.sleep(1)
print("Cu timeout de 3 secunde:", fetch_cu_timeout(BASE_URL, timeout=3).status_code)

time.sleep(1)

# Exercitiul 24. O singura sarcina pe functie
def get_title(html: str) -> str:
    """Extrage si returneaza titlul paginii dintr-un sir HTML."""
    start = html.find("<title>") + len("<title>")
    final = html.find("</title>")
    if start > len("<title>") - 1 and final != -1:
        return html[start:final].strip()
    return "Fara titlu"

print("\n--- Exercitiul 24 ---")
print("Titlul extras:", get_title(fetch(BASE_URL).text))

time.sleep(1)

# Exercitiul 25. Docstring-uri
print("\n--- Exercitiul 25 ---")
print("Afisare documentatie (help) pentru functia get_title:")
help(get_title)

time.sleep(1)

# Exercitiul 26. Adnotari de tip
print("\n--- Exercitiul 26 ---")
# Am folosit adnotari de tip (type hints) in functii (de ex: url: str -> int).
# Daca as apela get_status(123), Python nu opreste executia si ruleaza codul, 
# pentru ca Python este un limbaj cu tipizare dinamica; adnotarile sunt doar orientative 
# pentru programator sau pentru unelte externe de verificare.

time.sleep(1)

# Exercitiul 27. Fara opriri neasteptate
def page_exists(url: str) -> bool:
    """Verifica daca o pagina exista, returnand True sau False fara a opri programul."""
    try:
        r = requests.get(url, timeout=TIMEOUT)
        return r.ok
    except requests.RequestException:
        return False

print("\n--- Exercitiul 27 ---")
print("Exista cybercor.org?:", page_exists(BASE_URL))
print("Exista domeniu invalid?:", page_exists("https://this-domain-does-not-exist.invalid"))

time.sleep(1)

# Exercitiul 28. Returnarea unui dictionar
def check_paths(base: str, paths: list) -> dict:
    """Verifica o lista de cai si returneaza un dictionar {path: status_code}."""
    rezultate = {}
    for p in paths:
        url_complet = base + p
        try:
            r = requests.get(url_complet, timeout=TIMEOUT)
            rezultate[p] = r.status_code
        except requests.RequestException:
            rezultate[p] = None
        time.sleep(1)
    return rezultate

print("\n--- Exercitiul 28 ---")
print(check_paths(BASE_URL, ["/", "/robots.txt"]))

time.sleep(1)

# Exercitiul 29. Argumente cu nume
def get_header(url: str, name: str, default: str = "lipseste") -> str:
    """Returneaza valoarea unui singur antet HTTP."""
    r = requests.get(url, timeout=TIMEOUT)
    return r.headers.get(name, default)

print("\n--- Exercitiul 29 ---")
print("Antetul Server:", get_header(BASE_URL, name="Server"))

time.sleep(1)

# Exercitiul 30. Antete de securitate
def security_headers(url: str) -> dict:
    """Verifica prezenta celor 5 antete de securitate si returneaza un dictionar cu True/False."""
    antete_cerute = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    r = requests.get(url, timeout=TIMEOUT)
    verificare = {}
    for antet in antete_cerute:
        verificare[antet] = antet in r.headers
    return verificare

print("\n--- Exercitiul 30 ---")
print(security_headers(BASE_URL))

time.sleep(1)

# Exercitiul 31. Functii care apeleaza functii
def score_headers(results: dict) -> str:
    """Primeste dictionarul de securitate si returneaza un sir de tip 'X/5'."""
    total = len(results)
    gasite = sum(1 for val in results.values() if val)
    return f"{gasite}/{total}"

print("\n--- Exercitiul 31 ---")
print("Scor securitate:", score_headers(security_headers(BASE_URL)))

time.sleep(1)

# Exercitiul 32. Doua functii, o sarcina
def fetch_robots(base: str) -> str:
    """Returneaza continutul fisierului /robots.txt sau None daca lipseste."""
    try:
        r = requests.get(base + "/robots.txt", timeout=TIMEOUT)
        if r.status_code == 200:
            return r.text
    except requests.RequestException:
        pass
    return None

def disallowed_paths(robots_text: str) -> list:
    """Returneaza o lista cu toate valorile Disallow dintr-un text robots.txt."""
    if robots_text is None:
        return []
    rezultat = []
    for linie in robots_text.splitlines():
        if "Disallow:" in linie:
            valoare = linie.split("Disallow:")[1].strip()
            if valoare:
                rezultat.append(valoare)
    return rezultat

print("\n--- Exercitiul 32 ---")
txt_rob = fetch_robots(BASE_URL)
print("Cai interzise:", disallowed_paths(txt_rob))

time.sleep(1)

# Exercitiul 33. Oricate argumente
def response_times(*urls: str) -> dict:
    """Masoara timpul de raspuns pentru un numar variabil de URL-uri si returneaza {url: secunde}."""
    rezultate = {}
    for u in urls:
        start = time.perf_counter()
        try:
            requests.get(u, timeout=TIMEOUT)
            durata = time.perf_counter() - start
            rezultate[u] = round(durata, 3)
        except requests.RequestException:
            rezultate[u] = None
        time.sleep(1)
    return rezultate

print("\n--- Exercitiul 33 ---")
print(response_times(BASE_URL, "https://httpbin.org/get"))

time.sleep(1)

# Exercitiul 34. Argumente cu nume colectate
def log(message: str, **details):
    """Afiseaza un mesaj urmat de fiecare detaliu primit sub forma cheie=valoare."""
    detalii_formate = " | ".join(f"{k}={v}" for k, v in details.items())
    if detalii_formate:
        print(f"{message} | {detalii_formate}")
    else:
        print(message)

print("\n--- Exercitiul 34 ---")
log("verificat", url=BASE_URL, status=200)
# Diferenta dintre print() in interiorul unei functii si return: 
# print() afiseaza valoarea pe ecran si se pierde (nu o pot refolosi), pe cand 
# return trimite valoarea inapoi in program, permitandu-mi sa o salvez intr-o 
# variabila si s-o folosesc mai departe.