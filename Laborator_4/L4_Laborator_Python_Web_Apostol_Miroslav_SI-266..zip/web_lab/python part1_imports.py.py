# Laborator: functii, metode si importuri pe web
# Student: Apostol Miroslav, grupa SI-266

import time
import requests
import urllib.request

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercitiul 1. Primul import
print("--- Exercitiul 1 ---")
print("Versiunea bibliotecii requests este:", requests.__version__)
# Am importat requests si urllib.request. 
# De ce requests a avut nevoie de pip install, iar urllib nu? 
# Pentru ca urllib face parte din biblioteca standard Python (vine deja instalata 
# odata cu Python), pe cand requests este o biblioteca externa creata de altcineva 
# si trebuie s-o descarc separat de pe internet folosind comanda pip.

time.sleep(1)

# Exercitiul 2. Doua stiluri de import
print("\n--- Exercitiul 2 ---")
response_v1 = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (stil 1 - import requests):", response_v1.status_code)

from requests import get
response_v2 = get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (stil 2 - from requests import get):", response_v2.status_code)
# Avantaj stil 1 (import requests): codul este mai clar pentru ca vad exact din 
# ce modul provine functia (requests.get).
# Avantaj stil 2 (from requests import get): scriu mai putin cod pentru ca 
# folosesc direct functia get() fara sa mai scriu numele modulului in fata.

time.sleep(1)

# Exercitiul 3. Alias-uri
print("\n--- Exercitiul 3 ---")
import requests as rq
response_alias = rq.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare cu alias (rq):", response_alias.status_code)
# Un alias (cum ar fi import requests as rq) face codul mai scurt si mai usor de 
# citit atunci când modulul are un nume lung. Totusi, poate face codul mai greu de 
# inteles daca folosesc prescurtari necunoscute sau ciudate.

time.sleep(1)

# Exercitiul 4. Doar biblioteca standard
print("\n--- Exercitiul 4 ---")
req = urllib.request.Request(BASE_URL, headers={"User-Agent": "WebLab-ApostolMiroslav"})
std_response = urllib.request.urlopen(req)
print("Status cu urllib:", std_response.status)
corp_bytes = std_response.read(200)
print("Primele 200 caractere:", corp_bytes.decode("utf-8"))
# Indiciu aplicat: .read() returneaza bytes, iar .decode("utf-8") ii transforma in sir de caractere.

time.sleep(1)

# Exercitiul 5. Priviti in interiorul unui modul
print("\n--- Exercitiul 5 ---")
# print(dir(requests)) # Lasat comentat ca sa nu incarce ecranul
# Am ales trei nume din dir(requests) si le explic:
# 1. 'get' -> este o functie care trimite cereri HTTP de tip GET.
# 2. 'Response' -> este o clasa care reprezinta obiectul raspuns intors de server.
# 3. 'json' -> este un modul intern folosit pentru prelucrarea datelor JSON.

time.sleep(1)

# Exercitiul 6. Cititi documentatia
print("\n--- Exercitiul 6 ---")
# help(requests.get) # Afiseaza documentatia functiei in terminal
# Din documentatie am aflat ca parametrul pentru timpul maxim de asteptare se numeste timeout.
response_doc = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cerere cu timeout explicit reusita, status:", response_doc.status_code)

time.sleep(1)

# Exercitiul 7. Cronometrarea unei cereri
print("\n--- Exercitiul 7 ---")
start_time = time.perf_counter()
response_time_test = requests.get(BASE_URL, timeout=TIMEOUT)
end_time = time.perf_counter()

timp_calculat = end_time - start_time
print("Timpul masurat de mine cu time.perf_counter():", timp_calculat, "secunde")
print("Timpul oferit de response.elapsed:", response_time_test.elapsed.total_seconds(), "secunde")

time.sleep(1)

# Exercitiul 8. Cand un import esueaza
print("\n--- Exercitiul 8 ---")
try:
    import bs4
    print("Modulul bs4 este instalat.")
except ImportError:
    print("Instalati modulul cu: pip install beautifulsoup4")
# Diferenta de baza: un modul este un fisier Python (.py), un pachet este un director 
# care contine mai multe module (si fisierul __init__.py), iar o biblioteca este o 
# colectie mai mare de pachete si module (cum este biblioteca standard sau PyPI).