# Laborator: functii, metode si importuri pe web
# Student: Apostol Miroslav, grupa SI-266

import time
import hashlib
import json
import socket
import ssl
from datetime import datetime
import re
from html.parser import HTMLParser
from urllib.parse import urlparse, urljoin
import requests

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

# Exercitiul 35. Descompunerea unui URL
print("--- Exercitiul 35 ---")
parsed_url = urlparse("https://cybercor.org/path?x=1#top")
print("scheme:", parsed_url.scheme)
print("netloc:", parsed_url.netloc)
print("path:", parsed_url.path)
print("query:", parsed_url.query)
print("fragment:", parsed_url.fragment)

time.sleep(1)

# Exercitiul 36. Compunerea URL-urilor
print("\n--- Exercitiul 36 ---")
rel_links = ["/about", "contact.html", "../index.html"]
for link in rel_links:
    print(urljoin(BASE_URL, link))

time.sleep(1)

# Exercitiul 37. Extragerea legaturilor
def extract_links(html: str) -> list:
    """Extrage toate legaturile de pe pagina si returneaza o lista fara duplicate."""
    toate = re.findall(r'href="([^"]+)"', html)
    return list(set(toate))

print("\n--- Exercitiul 37 ---")
r_html = requests.get(BASE_URL, timeout=TIMEOUT).text
print("Numar legaturi unice gasite:", len(extract_links(r_html)))

time.sleep(1)

# Exercitiul 38. Interne sau externe?
def split_links(links: list, domain: str) -> tuple:
    """Imparte o lista de legaturi in doua liste: interne si externe."""
    interne = []
    externe = []
    for l in links:
        url_complet = urljoin(BASE_URL, l)
        netloc = urlparse(url_complet).netloc
        if domain in netloc:
            interne.append(url_complet)
        else:
            externe.append(url_complet)
    return interne, externe

print("\n--- Exercitiul 38 ---")
linkuri_extrase = extract_links(r_html)
int_l, ext_l = split_links(linkuri_extrase, "cybercor.org")
print("Interne:", len(int_l), "| Externe:", len(ext_l))

time.sleep(1)

# Exercitiul 39. Propriile metode (HTMLParser)
class ImageFinder(HTMLParser):
    """Clasa personalizata pentru gasirea atributelor src din etichetele <img>."""
    def __init__(self):
        super().__init__()
        self.images = []
 
    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            src_val = dict(attrs).get("src")
            if src_val:
                self.images.append(src_val)

print("\n--- Exercitiul 39 ---")
test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fara src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""
finder = ImageFinder()
finder.feed(test_html)
assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp",
], "Parserul nu a gasit exact imaginile asteptate"
print("Testul local pentru ImageFinder a trecut cu succes!")

time.sleep(1)

# Exercitiul 40. Amprenta paginii
def page_fingerprint(url: str) -> str:
    """Calculeaza amprenta SHA-256 a continutului paginii web."""
    resp = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(resp.content).hexdigest()

print("\n--- Exercitiul 40 ---")
print("Amprenta 1:", page_fingerprint(BASE_URL))
print("Amprenta 2:", page_fingerprint(BASE_URL))
# Rezultatele sunt identice daca pagina nu s-a modificat pe server intre timp. 
# Ar fi diferite daca continutul site-ului s-ar fi schimbat.

time.sleep(1)

# Exercitiul 41. Salvarea in JSON
print("\n--- Exercitiul 41 ---")
resp_j = requests.get(BASE_URL, timeout=TIMEOUT)
with open("headers.json", "w", encoding="utf-8") as f:
    json.dump(dict(resp_j.headers), f, indent=2)

with open("headers.json", "r", encoding="utf-8") as f:
    date_incarcate = json.load(f)
print("Antet Content-Type citit din fisierul JSON:", date_incarcate.get("Content-Type"))

time.sleep(1)

# Exercitiul 42. Interogare DNS
def resolve(hostname: str) -> str:
    """Returneaza adresa IP a unui domeniu prin interogare DNS."""
    return socket.gethostbyname(hostname)

print("\n--- Exercitiul 42 ---")
print("Adresa IP pentru cybercor.org:", resolve("cybercor.org"))

time.sleep(1)

# Exercitiul 43. Expirarea certificatului
def cert_days_left(hostname: str) -> int:
    """Returneaza cate zile mai sunt pana la expirarea certificatului SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            data_secunde = ssl.cert_time_to_seconds(cert["notAfter"])
            return int((data_secunde - time.time()) // 86400)

print("\n--- Exercitiul 43 ---")
try:
    print("Zile ramase pana la expirarea certificatului SSL:", cert_days_left("cybercor.org"))
except Exception as e:
    print("Nu s-a putut citi certificatul:", e)

# In exercitiul 39, cine apeleaza handle_starttag()? 
# Metoda handle_starttag() este apelata automat din interior de metoda .feed() a 
# clasei parinte HTMLParser, eu doar am suprascris-o ca sa implementez logica dorita.